require("dotenv").config();

module.exports = {
  token: process.env.DISCORD_TOKEN,
  clientId: process.env.CLIENT_ID,
  guildId: process.env.DEV_GUILD_ID || null,
  lavalinkNode: {
    id: "main",
    host: process.env.LAVALINK_HOST || "lavalink.jirayu.net",
    port: Number(process.env.LAVALINK_PORT || 443),
    authorization: process.env.LAVALINK_PASSWORD || "youshallnotpass",
    secure: String(process.env.LAVALINK_SECURE || "true") === "true",
  },
};
