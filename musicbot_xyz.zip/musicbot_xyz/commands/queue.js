const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { requirePlayer, formatDuration } = require("../utils");
const { getConsistentThumbnail, getPlatformDetails } = require("../imageUtils");

module.exports = {
  data: new SlashCommandBuilder().setName("queue").setDescription("Show the current queue"),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client);
    if (!player) return;

    const current = player.queue.current;
    const upcoming = player.queue.tracks.slice(0, 10);

    let embedColor = 0x5865f2;
    let thumbnail = null;
    let authorText = "Queue";
    let platformIcon = null;

    if (current) {
      const originalQuery = current.originalSpotifyUrl || current.originalQuery || current.info.uri;
      const platform = getPlatformDetails(originalQuery);
      embedColor = platform.color;
      platformIcon = platform.icon;
      thumbnail = await getConsistentThumbnail(current, originalQuery);
    }

    const embed = new EmbedBuilder().setColor(embedColor);

    if (platformIcon) {
      embed.setAuthor({ name: authorText, iconURL: platformIcon });
    } else {
      embed.setTitle(authorText);
    }

    if (thumbnail) {
      embed.setThumbnail(thumbnail);
    }

    if (current) {
      embed.addFields({
        name: "Now Playing",
        value: `**${current.info.title}** by \`${current.info.author}\` (${formatDuration(
          current.info.length || current.info.duration
        )})`,
      });
    }

    if (upcoming.length) {
      embed.addFields({
        name: `Up Next (${player.queue.tracks.length} total)`,
        value: upcoming
          .map((t, i) => `**${i + 1}.** ${t.info.title}`)
          .join("\n"),
      });
    } else {
      embed.addFields({ name: "Up Next", value: "Queue is empty." });
    }

    await interaction.reply({ embeds: [embed] });
  },
};
