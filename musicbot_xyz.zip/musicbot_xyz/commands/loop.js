const { SlashCommandBuilder } = require("discord.js");
const { requirePlayer } = require("../utils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("loop")
    .setDescription("Set the repeat mode")
    .addStringOption((opt) =>
      opt
        .setName("mode")
        .setDescription("What to repeat")
        .setRequired(true)
        .addChoices(
          { name: "Off", value: "off" },
          { name: "Track", value: "track" },
          { name: "Queue", value: "queue" }
        )
    ),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client);
    if (!player) return;

    const mode = interaction.options.getString("mode", true);
    player.setRepeatMode(mode);

    const labels = { off: "disabled", track: "repeating current track", queue: "repeating queue" };
    await interaction.reply(`Loop mode: **${labels[mode]}**.`);
  },
};
