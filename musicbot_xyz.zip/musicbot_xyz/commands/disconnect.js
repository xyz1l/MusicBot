const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { requirePlayer, formatDuration } = require("../utils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("disconnect")
    .setDescription("Disconnect the bot from voice (alias for /stop)"),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client);
    if (!player) return;

    const channelName = interaction.guild.channels.cache.get(player.voiceChannelId)?.name || 'voice channel';
    const track = player.queue.current;

    // Save these before destroying the player
    let platformColor = '#2b2d31';
    let platformName = 'Music';
    let platformIcon = interaction.client.user.displayAvatarURL();
    let thumbnailUrl = null;
    let trackTitle = null;
    let trackAuthor = null;
    let positionStr = null;
    let durationStr = null;

    if (track) {
      trackTitle = track.info.title;
      trackAuthor = track.info.author;
      positionStr = formatDuration(player.position);
      durationStr = formatDuration(track.info.length || track.info.duration);

      const uri = track.info.uri || '';
      if (uri.includes('youtube.com') || uri.includes('youtu.be')) {
        platformColor = '#FF0000';
        platformName = 'YouTube';
        platformIcon = 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/YouTube_full-color_icon_(2017).svg/2560px-YouTube_full-color_icon_(2017).svg.png';
      } else if (uri.includes('spotify')) {
        platformColor = '#1DB954';
        platformName = 'Spotify';
        platformIcon = 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Spotify_logo_without_text.svg/2048px-Spotify_logo_without_text.svg.png';
      }

      thumbnailUrl = track.info.artworkUrl;
      if (!thumbnailUrl && (uri.includes('youtube.com') || uri.includes('youtu.be'))) {
        const match = uri.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
        if (match) thumbnailUrl = `https://img.youtube.com/vi/${match[1]}/maxresdefault.jpg`;
      }
    }

    await player.destroy();

    const embed = new EmbedBuilder()
      .setColor(platformColor)
      .setAuthor({
        name: `Disconnected from ${channelName}`,
        iconURL: platformIcon
      })
      .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
      .setTimestamp();

    if (track) {
      embed.setTitle(trackTitle.length > 100 ? `${trackTitle.substring(0, 97)}...` : trackTitle)
        .setDescription(`**${trackAuthor.length > 100 ? `${trackAuthor.substring(0, 97)}...` : trackAuthor}**`)
        .addFields([
          { name: 'Stopped At', value: `${positionStr} / ${durationStr}`, inline: true },
          { name: 'Platform', value: platformName, inline: true },
          { name: 'Status', value: 'Disconnected', inline: true }
        ]);
      if (thumbnailUrl) embed.setImage(thumbnailUrl);
    } else {
      embed.setDescription(`**Successfully disconnected**`);
    }

    await interaction.reply({ embeds: [embed] });
  },
};
