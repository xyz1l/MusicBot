const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const { requirePlayer } = require("../utils");

module.exports = {
  data: new SlashCommandBuilder().setName("pause").setDescription("Pause the current song"),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client, { requireQueue: true });
    if (!player) return;

    if (player.paused) {
      return interaction.reply({ content: "⏸ Already paused.", flags: MessageFlags.Ephemeral });
    }

    await player.pause();
    await interaction.reply({ content: "⏸ Paused.", flags: MessageFlags.Ephemeral });

    // Edit the original "Now Playing" embed to show "Paused" status (after replying)
    if (player.nowPlayingMessage && player.nowPlayingData) {
      try {
        const oldEmbed = player.nowPlayingMessage.embeds[0];

        const updatedEmbed = EmbedBuilder.from(oldEmbed)
          .setAuthor({ name: 'Paused', iconURL: oldEmbed.author?.iconURL })
          .spliceFields(2, 1, { name: 'Status', value: 'Paused', inline: true });

        await player.nowPlayingMessage.edit({
          embeds: [updatedEmbed],
          components: player.nowPlayingMessage.components
        });
      } catch (e) {
        console.error('Could not edit now playing message:', e.message);
      }
    }
  },
};

