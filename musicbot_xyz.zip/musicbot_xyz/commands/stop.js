const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { requirePlayer, formatDuration } = require("../utils");
const { getConsistentThumbnail, getPlatformDetails } = require("../imageUtils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("stop")
    .setDescription("Stop playback, clear the queue, and leave the voice channel"),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client);
    if (!player) return;

    await interaction.deferReply();

    const channelName = interaction.guild.channels.cache.get(player.voiceChannelId)?.name || 'voice channel';
    const track = player.queue.current;

    // Save these before destroying the player
    let platformColor = '#2b2d31';
    let platformName = 'Music';
    let platformIcon = interaction.client.user.displayAvatarURL();
    let thumbnailUrl = null;
    let trackTitle = null;
    let trackAuthor = null;
    let positionStr = null;
    let durationStr = null;

    if (track) {
      trackTitle = track.info.title;
      trackAuthor = track.info.author;
      positionStr = formatDuration(player.position);
      durationStr = formatDuration(track.info.length || track.info.duration);

      const originalQuery = track.originalSpotifyUrl || track.originalQuery || track.info.uri;
      const platform = getPlatformDetails(originalQuery);

      platformColor = platform.color;
      platformName = platform.name;
      platformIcon = platform.icon;

      thumbnailUrl = await getConsistentThumbnail(track, originalQuery);
    }

    await player.destroy();

    const embed = new EmbedBuilder()
      .setColor(platformColor)
      .setAuthor({
        name: `Stopped in ${channelName}`,
        iconURL: platformIcon
      })
      .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
      .setTimestamp();

    if (track) {
      embed.setTitle(trackTitle.length > 100 ? `${trackTitle.substring(0, 97)}...` : trackTitle)
        .setDescription(`**${trackAuthor.length > 100 ? `${trackAuthor.substring(0, 97)}...` : trackAuthor}**`)
        .addFields([
          { name: 'Stopped At', value: `${positionStr} / ${durationStr}`, inline: true },
          { name: 'Platform', value: platformName, inline: true },
          { name: 'Status', value: 'Stopped', inline: true }
        ]);
      if (thumbnailUrl) embed.setImage(thumbnailUrl);
    } else {
      embed.setDescription(`⏹ **Successfully stopped playback**`);
    }

    await interaction.editReply({ embeds: [embed] });
  },
};
