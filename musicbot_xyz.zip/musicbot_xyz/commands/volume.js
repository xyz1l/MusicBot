const { SlashCommandBuilder } = require("discord.js");
const { requirePlayer } = require("../utils");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("volume")
    .setDescription("Set the playback volume")
    .addIntegerOption((opt) =>
      opt.setName("percent").setDescription("0-200").setRequired(true).setMinValue(0).setMaxValue(200)
    ),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client);
    if (!player) return;

    const percent = interaction.options.getInteger("percent", true);
    await player.setVolume(percent);
    await interaction.reply(`Volume set to **${percent}%**.`);
  },
};
