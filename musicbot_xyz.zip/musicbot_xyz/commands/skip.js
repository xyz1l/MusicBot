const { SlashCommandBuilder } = require("discord.js");
const { requirePlayer } = require("../utils");

module.exports = {
  data: new SlashCommandBuilder().setName("skip").setDescription("Skip the current song"),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client, { requireQueue: true });
    if (!player) return;

    const skipped = player.queue.current;
    await player.skip();
    await interaction.reply(`⏭ Skipped **${skipped.info.title}**.`);
  },
};
