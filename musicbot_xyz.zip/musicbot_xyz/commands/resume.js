const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const { requirePlayer } = require("../utils");

module.exports = {
  data: new SlashCommandBuilder().setName("resume").setDescription("Resume the current song"),

  async execute(interaction, client) {
    const player = await requirePlayer(interaction, client, { requireQueue: true });
    if (!player) return;

    if (!player.paused) {
      return interaction.reply({ content: "▶ Already playing.", flags: MessageFlags.Ephemeral });
    }

    await player.resume();
    await interaction.reply({ content: "▶ Resumed.", flags: MessageFlags.Ephemeral });

    // Edit the original embed to show "Now Playing" status again (after replying)
    if (player.nowPlayingMessage && player.nowPlayingData) {
      try {
        const oldEmbed = player.nowPlayingMessage.embeds[0];

        const updatedEmbed = EmbedBuilder.from(oldEmbed)
          .setAuthor({ name: 'Now Playing', iconURL: oldEmbed.author?.iconURL })
          .spliceFields(2, 1, { name: 'Status', value: 'Now Playing', inline: true });

        await player.nowPlayingMessage.edit({
          embeds: [updatedEmbed],
          components: player.nowPlayingMessage.components
        });
      } catch (e) {
        console.error('Could not edit now playing message:', e.message);
      }
    }
  },
};
