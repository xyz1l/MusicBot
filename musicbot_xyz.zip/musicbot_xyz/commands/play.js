const { SlashCommandBuilder, MessageFlags, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require("discord.js");
const axios = require('axios');
const { getConsistentThumbnail, getPlatformDetails, FALLBACK_IMAGES } = require('../imageUtils');



module.exports = {
  data: new SlashCommandBuilder()
    .setName("play")
    .setDescription("Play a song or add it to the queue")
    .addStringOption((opt) =>
      opt
        .setName("query")
        .setDescription("Song name, keywords, or URL (YouTube/SoundCloud/etc.)")
        .setRequired(true)
    ),

  async execute(interaction, client) {
    const voiceChannel = interaction.member.voice.channel;
    if (!voiceChannel) {
      return interaction.reply({ content: " Join a voice channel first.", flags: MessageFlags.Ephemeral });
    }

    const permissions = voiceChannel.permissionsFor(interaction.guild.members.me);
    if (!permissions.has(["Connect", "Speak"])) {
      return interaction.reply({
        content: "❌ I need `Connect` and `Speak` permissions in that voice channel.",
        flags: MessageFlags.Ephemeral,
      });
    }

    await interaction.deferReply();
    const query = interaction.options.getString("query", true);

    let player = client.lavalink.getPlayer(interaction.guildId);
    if (!player) {
      player = client.lavalink.createPlayer({
        guildId: interaction.guildId,
        voiceChannelId: voiceChannel.id,
        textChannelId: interaction.channelId,
        selfDeaf: true,
        selfMute: false,
      });
    }

    if (!player.connected) await player.connect();

    // Handle Spotify URLs - convert to YouTube search since Lavalink node has no Spotify plugin
    let searchQuery = query;
    let originalSpotifyUrl = null;
    if (query.includes('open.spotify.com/')) {
      originalSpotifyUrl = query;
      try {
        const resHtml = await axios.get(query, {
          timeout: 5000,
          headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
        });

        const match = resHtml.data.match(/<title>(.*?)<\/title>/);
        if (match && match[1]) {
          let title = match[1];
          // Example: "Song Name - song and lyrics by Artist | Spotify"
          title = title.replace(/ - song and lyrics by /gi, ' ');
          title = title.replace(/ - song by /gi, ' ');
          title = title.replace(/ - Single by /gi, ' ');
          title = title.replace(/ - EP by /gi, ' ');
          title = title.replace(/ - Album by /gi, ' ');
          title = title.replace(/ \| Spotify/gi, '');
          searchQuery = title.trim();
          console.log(`🎵 Spotify -> YouTube search: "${searchQuery}"`);
        }
      } catch (spotifyErr) {
        console.error('Spotify HTML scrape failed, trying raw query:', spotifyErr.message);
      }
    }

    const res = await player.search({ query: searchQuery }, interaction.user).catch(() => null);

    if (!res || !res.tracks?.length) {
      return interaction.editReply(`❌ No results found for **${query}**.`);
    }

    if (res.loadType === "playlist") {
      res.tracks.forEach(t => {
        t.originalQuery = query;
        t.originalSpotifyUrl = originalSpotifyUrl;
      });
      player.queue.add(res.tracks);
      await interaction.editReply(
        `📃 Queued playlist **${res.playlist?.name ?? "playlist"}** — ${res.tracks.length} tracks.`
      );
    } else {
      const track = res.tracks[0];
      track.originalQuery = query;
      track.originalSpotifyUrl = originalSpotifyUrl;

      const isNowPlaying = !player.playing && !player.paused;

      player.queue.add(track);

      let thumbnail;
      try {
        thumbnail = await getConsistentThumbnail(track, originalSpotifyUrl || query);
      } catch (thumbnailError) {
        console.error('Thumbnail error, using fallback:', thumbnailError);
        thumbnail = FALLBACK_IMAGES[Math.floor(Math.random() * FALLBACK_IMAGES.length)];
      }

      const platform = getPlatformDetails(originalSpotifyUrl || track.info.uri || query);
      const status = isNowPlaying ? 'Now Playing' : 'Queued';
      const authorText = isNowPlaying ? 'Now Playing' : 'Added to Queue';

      const embed = createConsistentEmbed({
        title: track.info.title,
        author: track.info.author,
        duration: track.info.length || track.info.duration,
        platform,
        status,
        authorText,
        thumbnail,
        requestedBy: interaction.user
      });

      // Show only the button for the original platform
      const buttons = originalSpotifyUrl
        ? createPlatformButtons(originalSpotifyUrl)
        : createPlatformButtons(track.info.uri || query);

      await interaction.editReply({
        content: null,
        embeds: [embed],
        components: buttons ? [buttons] : []
      });

      // Store the now playing message so pause/resume can edit the Status field
      if (isNowPlaying) {
        const nowPlayingMsg = await interaction.fetchReply();
        player.nowPlayingMessage = nowPlayingMsg;
        player.nowPlayingData = {
          title: track.info.title,
          author: track.info.author,
          duration: track.info.length || track.info.duration,
          platform,
          thumbnail,
          requestedBy: interaction.user,
          buttons
        };
      }
    }

    if (!player.playing && !player.paused) await player.play();
  },
};

// --- HELPER FUNCTIONS ---
// Create embed with consistent sizing
function createConsistentEmbed({
  title,
  author,
  duration,
  platform,
  status,
  authorText,
  thumbnail,
  requestedBy
}) {
  return new EmbedBuilder()
    .setColor(platform.color)
    .setAuthor({
      name: authorText,
      iconURL: platform.icon
    })
    .setTitle(title.length > 100 ? `${title.substring(0, 97)}...` : title)
    .setDescription(`**${author.length > 100 ? `${author.substring(0, 97)}...` : author}**`)
    .setImage(thumbnail)
    .addFields([
      {
        name: 'Duration',
        value: formatDuration(duration),
        inline: true
      },
      {
        name: 'Platform',
        value: platform.name,
        inline: true
      },
      {
        name: 'Status',
        value: status,
        inline: true
      }
    ])
    .setFooter({
      text: `Requested by ${requestedBy.username}`,
      iconURL: requestedBy.displayAvatarURL()
    })
    .setTimestamp();
}



function formatDuration(ms) {
  if (!ms || isNaN(ms)) return '0:00';
  const totalSeconds = Math.floor(ms / 1000);
  const seconds = totalSeconds % 60;
  const minutes = Math.floor(totalSeconds / 60);
  const hours = Math.floor(minutes / 60);

  const pad = (n) => (n < 10 ? `0${n}` : n);
  if (hours > 0) return `${hours}:${pad(minutes)}:${pad(seconds)}`;
  return `${minutes}:${pad(seconds)}`;
}

function createPlatformButtons(url) {
  if (!url) return null;

  const row = new ActionRowBuilder();

  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    let videoId = null;
    const patterns = [
      /(?:youtube\.com\/watch\?v=)([^&\n?#]+)/,
      /(?:youtu\.be\/)([^&\n?#]+)/,
      /(?:youtube\.com\/embed\/)([^&\n?#]+)/,
      /(?:youtube\.com\/v\/)([^&\n?#]+)/,
      /(?:youtube\.com\/shorts\/)([^&\n?#]+)/,
    ];
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        videoId = match[1];
        break;
      }
    }
    if (videoId) {
      row.addComponents(
        new ButtonBuilder()
          .setLabel('Watch on YouTube')
          .setURL(`https://youtube.com/watch?v=${videoId}`)
          .setStyle(ButtonStyle.Link)
          .setEmoji('<:youtube:1363980001455902883>')
      );
    }
  }

  if (url.includes('spotify.com')) {
    const trackMatch = url.match(/track\/([a-zA-Z0-9]{22})/);
    if (trackMatch) {
      row.addComponents(
        new ButtonBuilder()
          .setLabel('Listen on Spotify')
          .setURL(`https://open.spotify.com/track/${trackMatch[1]}`)
          .setStyle(ButtonStyle.Link)
          .setEmoji('<:spotify:1396181335357522001>')
      );
    }
  }

  return row.components.length > 0 ? row : null;
}
