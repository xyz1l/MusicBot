const { ActivityType, PresenceUpdateStatus } = require("discord.js");

function setupPresence(client) {
  const presences = [
    {
      status: PresenceUpdateStatus.Online,
      activities: [{ name: "music", type: ActivityType.Playing }],
    },
    {
      status: PresenceUpdateStatus.Idle,
      activities: [{ name: "music", type: ActivityType.Playing }],
    },
  ];

  let index = 0;
  client.user.setPresence(presences[index]);

  setInterval(() => {
    index = (index + 1) % presences.length;
    client.user.setPresence(presences[index]);
  }, 15_000);
}

module.exports = { setupPresence };
