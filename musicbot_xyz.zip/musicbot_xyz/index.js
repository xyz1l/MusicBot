const fs = require("fs");
const path = require("path");
const { Client, GatewayIntentBits, Collection } = require("discord.js");
const { LavalinkManager } = require("lavalink-client");
const config = require("./config");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
  ],
});

client.commands = new Collection();
const commandsPath = path.join(__dirname, "commands");
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}
client.lavalink = new LavalinkManager({
  nodes: [config.lavalinkNode],
  sendToShard: (guildId, payload) => {
    const guild = client.guilds.cache.get(guildId);
    if (guild) guild.shard.send(payload);
  },
  client: {
    id: config.clientId,
    username: "MusicBot",
  },
  playerOptions: {
    onDisconnect: { autoReconnect: true, destroyPlayer: false },
    onEmptyQueue: { destroyAfterMs: 60_000 },
    defaultSearchPlatform: "ytsearch",
  },
  autoSkip: true,
});

client.on("raw", (d) => client.lavalink.sendRawData(d));

client.lavalink.nodeManager.on("error", (node, error) => {
  console.error(`[Lavalink Error] Node '${node.id}':`, error.message || error);
});

const eventsPath = path.join(__dirname, "events");
for (const file of fs.readdirSync(eventsPath).filter((f) => f.endsWith(".js"))) {
  const event = require(path.join(eventsPath, file));
  if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
  else client.on(event.name, (...args) => event.execute(...args, client));
}

client.lavalink.on("trackStart", (player, track) => {
  const channel = client.channels.cache.get(player.textChannelId);
  if (channel?.isTextBased()) {
  }
});

client.lavalink.on("queueEnd", (player) => {
  const channel = client.channels.cache.get(player.textChannelId);
  if (channel?.isTextBased()) {
    channel.send("📭 Queue finished. Leaving in 60s if nothing new is added.");
  }
});

client.lavalink.on("playerDestroy", () => { });

client.login(config.token);
