/**
 * Fetches the guild's active player and validates the caller is in the same
 * voice channel. Returns the player, or null after replying with an error.
 */
async function requirePlayer(interaction, client, { requireQueue = false } = {}) {
  const player = client.lavalink.getPlayer(interaction.guildId);

  if (!player) {
    await interaction.reply({ content: "❌ Nothing is playing right now.", ephemeral: true });
    return null;
  }

  const memberVoiceId = interaction.member.voice.channel?.id;
  if (memberVoiceId !== player.voiceChannelId) {
    await interaction.reply({
      content: "❌ You need to be in the same voice channel as the bot.",
      ephemeral: true,
    });
    return null;
  }

  if (requireQueue && !player.queue.current) {
    await interaction.reply({ content: "❌ Nothing is currently playing.", ephemeral: true });
    return null;
  }

  return player;
}

function formatDuration(ms) {
  if (!ms || ms <= 0) return "LIVE";
  const totalSeconds = Math.floor(ms / 1000);
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

module.exports = { requirePlayer, formatDuration };
