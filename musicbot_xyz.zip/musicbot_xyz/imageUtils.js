const axios = require('axios');

// 100% working fallback images
const FALLBACK_IMAGES = [
  'https://i.imgur.com/JQ4X7zP.png', // Music note (640x640)
  'https://i.imgur.com/7TTYVbK.png'  // Sound waves (640x640)
];

// Get thumbnail with consistent dimensions
async function getConsistentThumbnail(track, originalQuery) {
  // 1. Try track's built-in thumbnail first
  const artwork = track.info?.artworkUrl || track.thumbnail || (track.info && track.info.thumbnail);
  if (artwork && await checkImage(artwork)) {
    return standardizeThumbnail(artwork);
  }

  // 2. Extract from original query URL if it's a direct link
  const directThumbnail = await extractThumbnailFromUrl(originalQuery);
  if (directThumbnail) {
    return standardizeThumbnail(directThumbnail);
  }

  // 3. Extract from track URI
  const uriThumbnail = await extractThumbnailFromUrl(track.info?.uri || track.uri);
  if (uriThumbnail) {
    return standardizeThumbnail(uriThumbnail);
  }

  // 4. Try oEmbed for YouTube videos
  if (originalQuery && (originalQuery.includes('youtube.com') || originalQuery.includes('youtu.be'))) {
    const videoIdMatch = originalQuery.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/);
    if (videoIdMatch) {
      const oembedThumbnail = await getYouTubeThumbnailViaOEmbed(videoIdMatch[1]);
      if (oembedThumbnail) {
        return standardizeThumbnail(oembedThumbnail);
      }
    }
  }

  // 5. Return random verified fallback
  return FALLBACK_IMAGES[Math.floor(Math.random() * FALLBACK_IMAGES.length)];
}

// Standardize thumbnail dimensions
function standardizeThumbnail(url) {
  if (!url) return url;

  // Spotify - ensure 640x640
  if (url.includes('i.scdn.co')) {
    return url.replace(/\/\d+x\d+\//, '/640x640/');
  }

  // YouTube - try to get highest quality available
  if (url.includes('ytimg.com') || url.includes('youtube.com')) {
    const videoIdMatch = url.match(/(?:vi\/|v=)([^\/]+)/);
    if (videoIdMatch) {
      const videoId = videoIdMatch[1];
      // Return maxresdefault directly, falling back if not available is handled externally if needed
      return `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`;
    }
  }

  return url;
}

// Enhanced YouTube thumbnail extraction
async function extractThumbnailFromUrl(url) {
  if (!url) return null;

  // Spotify URL - prioritize this extraction
  if (url.includes('spotify.com')) {
    const trackMatch = url.match(/track\/([a-zA-Z0-9]{22})/);
    if (trackMatch) {
      const trackId = trackMatch[1];
      const spotifyThumbnail = await getSpotifyThumbnail(trackId);
      if (spotifyThumbnail) return spotifyThumbnail;
    }
  }

  // YouTube URL
  if (url.includes('youtube.com') || url.includes('youtu.be')) {
    let videoId = null;
    
    const patterns = [
      /(?:youtube\.com\/watch\?v=)([^&\n?#]+)/,
      /(?:youtu\.be\/)([^&\n?#]+)/,
      /(?:youtube\.com\/embed\/)([^&\n?#]+)/,
      /(?:youtube\.com\/v\/)([^&\n?#]+)/,
      /(?:youtube\.com\/shorts\/)([^&\n?#]+)/,
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match) {
        videoId = match[1];
        break;
      }
    }
    
    if (videoId) {
      const youtubeUrls = [
        `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
        `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`,
        `https://img.youtube.com/vi/${videoId}/default.jpg`
      ];
      
      for (const youtubeUrl of youtubeUrls) {
        if (await checkImage(youtubeUrl)) {
          return youtubeUrl;
        }
      }
    }
  }

  return null;
}

// Get YouTube thumbnail via oEmbed
async function getYouTubeThumbnailViaOEmbed(videoId) {
  try {
    const oembedUrl = `https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`;
    const response = await axios.get(oembedUrl, { timeout: 3000 });
    
    if (response.data && response.data.thumbnail_url) {
      let thumbnailUrl = response.data.thumbnail_url;
      
      const maxResUrl = thumbnailUrl.replace('hqdefault', 'maxresdefault');
      if (await checkImage(maxResUrl)) {
        return maxResUrl;
      }
      
      return thumbnailUrl;
    }
  } catch (error) {
    // ignore
  }
  return null;
}

// Improved Spotify thumbnail extraction using oEmbed
async function getSpotifyThumbnail(trackId) {
  try {
    const response = await axios.get(`https://open.spotify.com/oembed?url=https://open.spotify.com/track/${trackId}`, {
      timeout: 5000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    if (response.data && response.data.thumbnail_url) {
      let imageUrl = response.data.thumbnail_url;
      if (imageUrl.includes('i.scdn.co/image/')) {
        imageUrl = imageUrl.replace(/\/(\d+x\d+)\//, '/640x640/');
      }
      return imageUrl;
    }
  } catch (error) {
    // ignore
  }
  
  return `https://i.scdn.co/image/ab67616d0000b273${trackId.slice(0, 16)}`;
}

// Check if image URL is valid
async function checkImage(url) {
  try {
    const response = await axios.head(url, {
      timeout: 5000,
      validateStatus: status => status >= 200 && status < 400,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });
    
    const contentType = response.headers['content-type'];
    const isImage = contentType?.startsWith('image/');
    const contentLength = response.headers['content-length'];
    
    if (isImage && contentLength && parseInt(contentLength) < 1000) {
      return false;
    }
    
    return isImage;
  } catch (error) {
    return false;
  }
}

// Platform detection with icons
function getPlatformDetails(url) {
  const platforms = {
    spotify: {
      name: 'Spotify',
      icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/19/Spotify_logo_without_text.svg/2048px-Spotify_logo_without_text.svg.png',
      color: '#1DB954'
    },
    youtube: {
      name: 'YouTube',
      icon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/YouTube_full-color_icon_(2017).svg/2560px-YouTube_full-color_icon_(2017).svg.png',
      color: '#FF0000'
    },
    default: {
      name: 'Music',
      icon: 'https://cdn-icons-png.flaticon.com/512/3669/3669483.png',
      color: '#5865F2'
    }
  };

  if (!url) return platforms.default;
  if (url.includes('spotify')) return platforms.spotify;
  if (url.includes('youtube') || url.includes('youtu.be')) return platforms.youtube;
  return platforms.default;
}

module.exports = {
  getConsistentThumbnail,
  getPlatformDetails,
  FALLBACK_IMAGES
};
