const { setupPresence } = require("../presence");

module.exports = {
  name: "clientReady",
  once: true,
  async execute(client) {
    console.log(`✅ Logged in as ${client.user.tag}`);
    client.lavalink.init({ id: client.user.id, username: client.user.username });
    setupPresence(client);
  },
};
